# GENERATED VERSION FILE
# TIME: Tue Dec  1 10:35:02 2020

__version__ = '2.3.0rc0+fb4007d'
short_version = '2.3.0rc0'
version_info = (2, 3, "0rc0")
