import numpy as np

from ..builder import PIPELINES


@PIPELINES.register_module()
class NormalizeBoxCoordinates(object):
    """Normalize coordinates of the ground truth bounding box to the input image size.

    After normalization coordinates will be clamped between 0 and 1.

    Args:
        image_size (int): Image size that will be used for the normalization.
    """

    def __init__(self, image_size: int):
        self.image_size = image_size

    def __call__(self, results):
        """Call function to normalize coordinates of the bounding boxes.

        Args:
            results (dict): Result dict from loading pipeline.

        Returns:
            dict: Results with normalized bounding boxes coordinates.
        """
        for key in results.get('bbox_fields', []):
            b_boxes = results[key] / self.image_size
            b_boxes = np.clip(b_boxes, 0, 1)
            results[key] = b_boxes
        return results

    def __repr__(self):
        return self.__class__.__name__ + f'(image_size={self.image_size})'


@PIPELINES.register_module()
class BBoxXY2YX(object):
    """Swap the X and Y coordinates of the bounding boxes.

    Some data sets use (x1, y1, x2, y2) coordinates format,
    whereas TF OD-API operates with bounding boxes in format (y1, x1, y2, x2).
    """

    def __call__(self, results):
        """Call function to swap the coordinates.

        Args:
            results (dict): Result dict from loading pipeline.

        Returns:
            dict: Results with swapped coordinates.
        """
        for key in results.get('bbox_fields', []):
            b_boxes = results[key]
            b_boxes = b_boxes[:, [1, 0, 3, 2]]
            results[key] = b_boxes
        return results

    def __repr__(self):
        return self.__class__.__name__
