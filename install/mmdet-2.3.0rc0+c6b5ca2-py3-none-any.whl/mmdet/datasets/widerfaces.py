import mmcv
import numpy as np

from .builder import DATASETS
from .custom import CustomDataset


@DATASETS.register_module()
class WiderFacesDatasetODAPI(CustomDataset):

    CLASSES = ('face',)

    @staticmethod
    def _get_box_from_od_specs(od_box_specs: dict) -> np.ndarray:
        """Get the box in format (x_min, y_min, x_max, y_max)"""
        x_min = od_box_specs['x_min']
        y_min = od_box_specs['y_min']
        width = od_box_specs['width']
        height = od_box_specs['height']
        box_coords = np.array([
            x_min,
            y_min,
            x_min + width,
            y_min + height,
        ], np.float32)
        return box_coords

    def load_annotations(self, ann_file):
        ann_data = mmcv.load(ann_file, 'json')

        data_infos = []
        # for filename, specs in list(ann_data.items())[:200]:
        for filename, specs in ann_data.items():
            bboxes = [
                self._get_box_from_od_specs(x)
                for x in specs['boxes'].values()
            ]
            if not bboxes:
                continue
            data_infos.append(
                dict(
                    filename=filename,
                    width=specs['image_width'],
                    height=specs['image_height'],
                    ann=dict(
                        bboxes=np.stack(bboxes, 0),
                        labels=np.zeros(len(bboxes), np.int64),
                    )
                )
            )

        return data_infos

    # def evaluate(
    #         self,
    #         results,
    #         metric='bbox',
    #         logger=None,
    #         jsonfile_prefix=None,
    #         classwise=False,
    #         proposal_nums=(100, 300, 1000),
    #         iou_thrs=np.arange(0.5, 0.96, 0.05),
    # ):
