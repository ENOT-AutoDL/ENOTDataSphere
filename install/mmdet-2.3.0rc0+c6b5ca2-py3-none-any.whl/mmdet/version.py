# GENERATED VERSION FILE
# TIME: Wed Dec  2 19:32:07 2020

__version__ = '2.3.0rc0+c6b5ca2'
short_version = '2.3.0rc0'
version_info = (2, 3, "0rc0")
