from typing import Dict
from typing import List
from typing import Optional
from typing import Tuple

import torch
import torch.nn as nn
from enot.models.mobilenet.stems import MobileNetBaseStem
from enot.models.search_space_model import SearchSpaceModel
from enot.models.simple_block_model_builders import build_frozen_simple_block_model
from enot.models.simple_block_model_builders import build_simple_block_model
from enot.models.simple_block_model_builders import make_divisible
from enot_utils.common_utils import init_convnet_params

from ..builder import BACKBONES

_ACTIVATIONS = {
    'relu': nn.ReLU,
    'relu6': nn.ReLU6,
}


class FeatureMapExtractor(nn.Sequential):

    def __init__(self, input_chs, output_chs, activation, width_fn):
        intermediate_chs = width_fn(output_chs // 2)

        super().__init__(
            nn.Conv2d(input_chs, intermediate_chs, 1, bias=False),
            nn.BatchNorm2d(intermediate_chs),
            activation(inplace=True),
            nn.Conv2d(intermediate_chs, intermediate_chs, 3, 2, 1, groups=intermediate_chs, bias=False),
            nn.BatchNorm2d(intermediate_chs),
            activation(inplace=True),
            nn.Conv2d(intermediate_chs, output_chs, 1, bias=False),
            nn.BatchNorm2d(output_chs),
            activation(inplace=True),
        )


class BackboneSimpleMobileNet(nn.Module):
    """SimpleMobileNet using to build final searched architecture"""

    def __init__(
            self,
            search_blocks: List[str],
            mob_net_params: Dict[str, List],
            stem: nn.Module,
            in_channels: int,
            activation: Optional[str] = 'relu6',
            min_channels: int = 8,
            round_nearest: int = 8,
            out_feature_indices=(21,),
            out_feature_widths=(None,),
    ):
        super().__init__()
        self.out_feature_indices = out_feature_indices
        self.out_feature_widths = out_feature_widths

        self.stem = stem is not None
        self.blocks = build_frozen_simple_block_model(
            in_channels=in_channels,
            blocks_op_name=list(search_blocks),
            blocks_out_channels=mob_net_params['output_channels'],
            blocks_count=mob_net_params['blocks_count'],
            blocks_stride=mob_net_params['strides'],
            stem=stem,
        )

        def width_fn(chs_):
            return make_divisible(chs_, round_nearest, min_channels)

        features_output_chs = []
        self.body_start_ind = int(self.stem)
        for block in self.blocks[self.body_start_ind:]:
            features_output_chs.append(block.search_variants.out_channels)

        last_probe_chs = None
        feature_probes = []

        if activation not in _ACTIVATIONS:
            raise ValueError(
                f'Unsupported activation function "{activation}", '
                f'use {list(_ACTIVATIONS)}.'
            )

        activation = _ACTIVATIONS[activation]

        for f_index, f_width in zip(self.out_feature_indices, self.out_feature_widths):
            if f_index is not None:
                feature_probes.append(None)
                last_probe_chs = features_output_chs[f_index - 1]
            else:
                feature_probes.append(
                    FeatureMapExtractor(last_probe_chs, f_width, activation, width_fn)
                )
                last_probe_chs = f_width

        self.features_probes = nn.ModuleList(feature_probes)

    def forward(self, x):
        selected_features_outputs = []
        feature_maps = []
        if self.stem:
            x = self.blocks[0](x)

        # Calculating features store the selected outputs for the feature maps probes
        for i, layer in enumerate(self.blocks[self.body_start_ind:], 1):
            x = layer(x)
            if i in self.out_feature_indices:
                selected_features_outputs.append(x)
            else:
                selected_features_outputs.append(None)

        for f_index, probe_module in zip(self.out_feature_indices, self.features_probes):
            if f_index is not None:
                feature_maps.append(selected_features_outputs[f_index - 1])
            else:
                feature_maps.append(
                    probe_module(feature_maps[-1])
                )

        return tuple(feature_maps)


class BackboneMobileNetSearchSpace(nn.Module):
    r"""Class for network search.

    Important note: this class is acceptable for NN search.
    """

    def __init__(
            self,
            search_blocks: List[str],
            mob_net_params: Dict[str, List],
            stem: nn.Module,
            in_channels: int,
            activation: Optional[str] = 'relu6',
            width_multiplier: float = 1.0,
            min_channels: int = 8,
            round_nearest: int = 8,
            out_feature_indices=(21,),
            out_feature_widths=(None,),
    ):
        super().__init__()
        self.width_multiplier = width_multiplier
        self.out_feature_indices = out_feature_indices
        self.out_feature_widths = out_feature_widths
        self.stem = stem is not None

        self.blocks = build_simple_block_model(
            in_channels,
            search_blocks,
            mob_net_params['output_channels'],
            mob_net_params['blocks_count'],
            mob_net_params['strides'],
            width_multiplier,
            min_channels,
            stem=stem,
        )

        def width_fn(chs_):
            return make_divisible(chs_, round_nearest, min_channels)

        def extract_out_channels_from_nas_block(block_):
            return block_.search_variants[0].squeeze_op.conv.out_channels

        features_output_chs = []
        self.body_start_ind = int(self.stem)
        for block in self.blocks[self.body_start_ind:]:
            features_output_chs.append(extract_out_channels_from_nas_block(block))

        last_probe_chs = None
        feature_probes = []

        if activation not in _ACTIVATIONS:
            raise ValueError(
                f'Unsupported activation function "{activation}", '
                f'use {list(_ACTIVATIONS)}.'
            )

        activation = _ACTIVATIONS[activation]

        for f_index, f_width in zip(self.out_feature_indices, self.out_feature_widths):
            if f_index is not None:
                feature_probes.append(None)
                last_probe_chs = features_output_chs[f_index - 1]
            else:
                feature_probes.append(
                    FeatureMapExtractor(last_probe_chs, f_width, activation, width_fn)
                )
                last_probe_chs = f_width

        self.features_probes = nn.ModuleList(feature_probes)

    def forward(self, x):
        selected_features_outputs = []
        feature_maps = []
        if self.stem:
            x = self.blocks[0](x)

        # Calculating features store the selected outputs for the feature maps probes
        for i, layer in enumerate(self.blocks[self.body_start_ind:], 1):
            x = layer(x)
            if i in self.out_feature_indices:
                selected_features_outputs.append(x)
            else:
                selected_features_outputs.append(None)

        for f_index, probe_module in zip(self.out_feature_indices, self.features_probes):
            if f_index is not None:
                feature_maps.append(selected_features_outputs[f_index - 1])
            else:
                feature_maps.append(
                    probe_module(feature_maps[-1])
                )

        return tuple(feature_maps)


@BACKBONES.register_module()
class MobileNetSearchSpace(SearchSpaceModel):
    def __init__(
            self,
            search_blocks: List[str],
            mob_net_params: Dict[str, List],
            activation: Optional[str] = 'relu6',
            width_multiplier: float = 1.0,
            min_channels: int = 8,
            round_nearest: int = 8,
            out_feature_indices=(21,),
            out_feature_widths=(None,),
            in_channels: int = 3,
            strides: Tuple[int, int] = (2, 1),
            output_channels: Tuple[int, int] = (32, 16),
            kernel_size: Tuple[int, int] = (3, 3),
            **search_blocks_extra_params,
    ):
        stem = MobileNetBaseStem(
            activation=activation,
            in_channels=in_channels,
            strides=strides,
            output_channels=output_channels,
            kernel_sizes=kernel_size,
            width_multiplier=width_multiplier,
            min_channels=min_channels,
        )

        model = BackboneMobileNetSearchSpace(
            search_blocks,
            mob_net_params,
            stem,
            output_channels[-1],
            activation,
            width_multiplier,
            min_channels,
            round_nearest,
            out_feature_indices,
            out_feature_widths,
        )

        super().__init__(model, **search_blocks_extra_params)

    def init_weights(self, pretrained=None):
        """Initialize the weights in backbone.

        Args:
            pretrained (str, optional): Path to pre-trained weights.
                Defaults to None.
        """

        init_convnet_params(self)

        if pretrained is not None:
            state_dict = torch.load(pretrained)
            self.load_state_dict(state_dict, strict=False)


@BACKBONES.register_module()
class SimpleMobileNet(BackboneSimpleMobileNet):

    def __init__(
            self,
            search_blocks: List[str],
            mob_net_params: Dict[str, List],
            activation: Optional[str] = 'relu6',
            in_channels: int = 3,
            strides: Tuple[int, int] = (2, 1),
            output_channels: Tuple[int, int] = (32, 16),
            kernel_size: Tuple[int, int] = (3, 3),
            width_multiplier: float = 1.0,
            min_channels: int = 8,
            round_nearest: int = 8,
            out_feature_indices=(21,),
            out_feature_widths=(None,),
    ):
        stem = MobileNetBaseStem(
            activation=activation,
            in_channels=in_channels,
            strides=strides,
            output_channels=output_channels,
            kernel_sizes=kernel_size,
            width_multiplier=width_multiplier,
            min_channels=min_channels,
        )
        super().__init__(
            search_blocks=search_blocks,
            mob_net_params=mob_net_params,
            in_channels=output_channels[-1],
            activation=activation,
            stem=stem,
            min_channels=min_channels,
            round_nearest=round_nearest,
            out_feature_indices=out_feature_indices,
            out_feature_widths=out_feature_widths,
        )

    def init_weights(self, pretrained=None):
        """Initialize the weights in backbone.

        Args:
            pretrained (str, optional): Path to pre-trained weights.
                Defaults to None.
        """

        init_convnet_params(self)

        if pretrained is not None:
            state_dict = torch.load(pretrained)
            self.load_state_dict(state_dict, strict=False)
