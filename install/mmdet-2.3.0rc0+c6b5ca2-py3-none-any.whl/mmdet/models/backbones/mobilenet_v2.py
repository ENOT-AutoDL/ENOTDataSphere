import torch.nn as nn
from mmcv.runner import load_checkpoint

from mmdet.utils import get_root_logger
from ..builder import BACKBONES

_DEFAULT_MOBILENET_CONFIG = [
    # t, c, n, s
    [1, 16, 1, 1],
    [6, 24, 2, 2],
    [6, 32, 3, 2],
    [6, 64, 4, 2],
    [6, 96, 3, 1],
    [6, 160, 3, 2],
    [6, 320, 1, 1],
]

_ACTIVATIONS = {
    'relu': nn.ReLU,
    'relu6': nn.ReLU6,
}


def _make_divisible(v, divisor, min_value=None):
    """
    This function is taken from the original tf repo.
    It ensures that all layers have a channel number that is divisible by 8 (for example)
    It can be seen here:
    https://github.com/tensorflow/models/blob/master/research/slim/nets/mobilenet/mobilenet.py
    """
    if min_value is None:
        min_value = divisor
    new_v = max(min_value, int(v + divisor / 2) // divisor * divisor)
    # Make sure that round down does not go down by more than 10%.
    if new_v < 0.9 * v:
        new_v += divisor
    return new_v


class ConvBNReLU(nn.Sequential):

    def __init__(self, in_planes, out_planes, kernel_size=3, stride=1, groups=1, activation=nn.ReLU):
        padding = (kernel_size - 1) // 2
        super().__init__(
            nn.Conv2d(in_planes, out_planes, kernel_size, stride, padding, groups=groups, bias=False),
            nn.BatchNorm2d(out_planes),
            activation(inplace=True)
        )


class FeatureMapExtractor(nn.Sequential):

    def __init__(self, input_chs, output_chs, activation, width_fn):
        intermediate_chs = width_fn(output_chs // 2)

        super().__init__(
            nn.Conv2d(input_chs, intermediate_chs, 1, bias=False),
            nn.BatchNorm2d(intermediate_chs),
            activation(inplace=True),
            nn.Conv2d(intermediate_chs, intermediate_chs, 3, 2, 1, groups=intermediate_chs, bias=False),
            nn.BatchNorm2d(intermediate_chs),
            activation(inplace=True),
            nn.Conv2d(intermediate_chs, output_chs, 1, bias=False),
            nn.BatchNorm2d(output_chs),
            activation(inplace=True),
        )


class InvertedResidual(nn.Module):

    def __init__(self, inp, oup, stride, expand_ratio, activation):
        super().__init__()
        self.stride = stride
        assert stride in [1, 2]

        hidden_dim = int(round(inp * expand_ratio))
        self.use_res_connect = self.stride == 1 and inp == oup

        layers = []
        if expand_ratio != 1:
            layers.append(ConvBNReLU(inp, hidden_dim, kernel_size=1, activation=activation))  # pw
        layers.extend([
            ConvBNReLU(hidden_dim, hidden_dim, stride=stride, groups=hidden_dim, activation=activation),  # dw
            nn.Conv2d(hidden_dim, oup, 1, 1, 0, bias=False),  # pw-linear
            nn.BatchNorm2d(oup),
        ])
        self.conv = nn.Sequential(*layers)

    def forward(self, x):
        if self.use_res_connect:
            return x + self.conv(x)
        return self.conv(x)


@BACKBONES.register_module()
class MobileNetV2SSDFeatureExtractor(nn.Module):
    """MobileNetV2 Backbone network for single-shot-detection feature maps extraction.

    Args:
        input_size (int): width and height of input.
        width_mult (float): Width multiplier - adjusts number of channels in each layer by this amount
        round_nearest (int): Round the number of channels in each layer to be a multiple of this number
            Set to 1 to turn off rounding
        out_feature_indices (Sequence[Optional[int]]): Layers from which features are collected as probes.
            Indexing starts from 1.
            None means get the previous probe.
            Must have the same length as out_feature_width.
        out_feature_widths (Sequence[Optional[int]]): Width of output probes
            Width of the corresponding feature probe.
            For explicitly specified layer in out_feature_indices, the width must be None.
            For implicitly specified probes the width must be an integer number.

    Example (not mine, using the original MMDet style for SSD examples):
        >>> import torch
        >>> module = MobileNetV2SSDFeatureExtractor(
        ...     input_size=300,
        ...     out_feature_indices=(19, None),
        ...     out_feature_widths=(None, 512),
        ... )
        >>> inputs = torch.rand(1, 3, 300, 300)
        >>> level_outputs = module.forward(inputs)
        >>> for level_out in level_outputs:
        ...     print(tuple(level_out.shape))
        (1, 1280, 10, 10)
        (1, 512, 5, 5)
    """

    def __init__(
            self,
            input_size,
            input_channel=32,
            last_channel=1280,
            width_mult=1.0,
            round_nearest=8,
            min_width=16,
            out_feature_indices=(19,),
            out_feature_widths=(None,),
            activation_function='relu',
    ):
        super().__init__()

        if activation_function not in _ACTIVATIONS:
            raise ValueError(
                f'Unsupported activation function "{activation_function}", '
                f'use {list(_ACTIVATIONS)}.'
            )

        activation = _ACTIVATIONS[activation_function]

        def width_fn(chs_):
            return _make_divisible(chs_, round_nearest, min_width)

        input_channel = width_fn(input_channel * width_mult)
        last_channel = width_fn(last_channel * max(1.0, width_mult))
        inverted_residual_setting = _DEFAULT_MOBILENET_CONFIG

        self.input_size = input_size

        # Building original MobileNet features
        # building the first layer
        features = [ConvBNReLU(3, input_channel, stride=2)]
        features_output_chs = [input_channel]

        # building inverted residual blocks
        for t, c, n, s in inverted_residual_setting:
            output_channel = _make_divisible(c * width_mult, round_nearest)
            for i in range(n):
                stride = s if i == 0 else 1
                features.append(
                    InvertedResidual(input_channel, output_channel, stride, t, activation)
                )
                input_channel = output_channel
                features_output_chs.append(output_channel)

        # building the last convolution layer
        features.append(ConvBNReLU(input_channel, last_channel, kernel_size=1))
        features_output_chs.append(last_channel)

        # Place the original features to the Module List
        self.features = nn.ModuleList(features)

        # Construct specifications for the feature maps
        self._check_output_features_specs(out_feature_indices, out_feature_widths)

        self.out_feature_indices = out_feature_indices
        self.out_feature_widths = [
            width_fn(w * width_mult) if w else features_output_chs[i - 1]
            for i, w in zip(out_feature_indices, out_feature_widths)
        ]

        # Build feature maps
        last_probe_chs = None
        feature_probes = []
        for f_index, f_width in zip(self.out_feature_indices, self.out_feature_widths):
            if f_index is not None:
                feature_probes.append(None)
                last_probe_chs = features_output_chs[f_index - 1]
            else:
                feature_probes.append(
                    FeatureMapExtractor(last_probe_chs, f_width, activation, width_fn)
                )
                last_probe_chs = f_width

        self.features_probes = nn.ModuleList(feature_probes)

    def _check_output_features_specs(self, out_feature_indices, out_feature_widths):
        if not isinstance(out_feature_indices, (list, tuple)):
            raise TypeError(
                f'Output features indices must be provided via a list or a tuple, '
                f'got {type(out_feature_indices)}'
            )

        if not isinstance(out_feature_widths, (list, tuple)):
            raise TypeError(
                f'Output features widths must be provided via a list or a tuple, '
                f'got {type(out_feature_indices)}'
            )

        if len(out_feature_indices) != len(out_feature_widths):
            raise ValueError(
                f'Length of out_feature_indices and out_feature_widths '
                f'must be the same, got {len(out_feature_indices)} '
                f'and {len(out_feature_widths)}.'
            )

        features_num = len(self.features)

        for i in out_feature_indices:
            if i is None:
                continue

            if not isinstance(i, int):
                raise TypeError(f'Output features indices must be integer values, got {type(i)}.')

            if i < 1 or i > features_num:
                raise ValueError(
                    f'Output features indices must range from 1 to {features_num}, got {i}.'
                )

        for w in out_feature_widths:
            if w is None:
                continue

            if not isinstance(w, int):
                raise TypeError(f'Output features widths must be integer values, got {type(w)}.')

            if w <= 0:
                raise ValueError(f'Output features width must be greater than 0, got {w}.')

        if out_feature_indices[0] is None:
            raise ValueError('First feature index must be specified explicitly. Got None.')

        for pos, (i, w) in enumerate(zip(out_feature_indices, out_feature_widths)):
            if i is None and w is None:
                raise ValueError(
                    f'Feature specification at position {pos}. '
                    f'If feature index is not specified, the feature width must be set explicitly.'
                )

            if i is not None and w is not None:
                raise ValueError(
                    f'Feature specification at position {pos}. '
                    f'Feature index is specified explicitly, the feature width must be None.'
                )

    def init_weights(self, pretrained=None):
        """Initialize the weights in backbone.

        Args:
            pretrained (str, optional): Path to pre-trained weights.
                Defaults to None.
        """
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                nn.init.kaiming_normal_(m.weight, mode='fan_out')
                if m.bias is not None:
                    nn.init.zeros_(m.bias)
            elif isinstance(m, nn.BatchNorm2d):
                nn.init.ones_(m.weight)
                nn.init.zeros_(m.bias)
            elif isinstance(m, nn.Linear):
                nn.init.normal_(m.weight, 0, 0.01)
                nn.init.zeros_(m.bias)

        if isinstance(pretrained, str):
            logger = get_root_logger()
            load_checkpoint(self, pretrained, strict=False, logger=logger)

        elif pretrained is not None:
            raise TypeError('pretrained must be a str or None')

    def forward(self, x):
        selected_features_outputs = []
        feature_maps = []

        # Calculating features store the selected outputs for the feature maps probes
        for i, layer in enumerate(self.features, 1):
            x = layer(x)
            if i in self.out_feature_indices:
                selected_features_outputs.append(x)
            else:
                selected_features_outputs.append(None)

        for f_index, probe_module in zip(self.out_feature_indices, self.features_probes):
            if f_index is not None:
                feature_maps.append(selected_features_outputs[f_index - 1])
            else:
                feature_maps.append(
                    probe_module(feature_maps[-1])
                )

        return tuple(feature_maps)
