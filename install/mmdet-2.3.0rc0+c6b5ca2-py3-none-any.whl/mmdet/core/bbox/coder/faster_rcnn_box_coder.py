from typing import Optional
from typing import Tuple

import torch

from .base_bbox_coder import BaseBBoxCoder
from ..builder import BBOX_CODERS

EPSILON = 1e-8


@BBOX_CODERS.register_module()
class FasterRcnnBoxCoder(BaseBBoxCoder):
    """Faster RCNN box coder.

    Implementation is copied from the Object Detection API expasoft-hosted repo
    `face_detector <https://gitlab.expasoft.com/Goncharenko/face_detector>`_

    The format is changed to X-Y-X-Y.

    Args:
        x_scale (float, optional): Scale factor for scaling tx.
        y_scale (float, optional): Scale factor for scaling ty.
        width_scale (float, optional): Scale factor for scaling tw.
        height_scale (float, optional): Scale factor for scaling th.
    """

    def __init__(
            self,
            x_scale: Optional[float],
            y_scale: Optional[float],
            width_scale: Optional[float],
            height_scale: Optional[float],
    ):
        """Constructor for FasterRcnnBoxCoder.

        Args:
            x_scale (float, optional): Scale factor for scaling tx.
            y_scale (float, optional): Scale factor for scaling ty.
            width_scale (float, optional): Scale factor for scaling tw.
            height_scale (float, optional): Scale factor for scaling th.
        """
        super().__init__()

        scale_factors = [x_scale, y_scale, width_scale, height_scale]
        scale_factors = [s for s in scale_factors if s is not None]

        if scale_factors:
            assert len(scale_factors) == 4
            for scalar in scale_factors:
                assert scalar > 0

        self._scale_factors = scale_factors

    @staticmethod
    def _get_center_coordinates_and_sizes(
            bounding_boxes: torch.Tensor,
    ) -> Tuple[torch.Tensor, torch.Tensor, torch.Tensor, torch.Tensor]:
        """

        Args:
            bounding_boxes (torch.Tensor): Bounding boxes in format (y1, x1, y2, x2)

        Returns:
            tuple of torch.Tensor: centers and sizes of the boxes (four tensors).
        """

        x1, y1, x2, y2 = torch.unbind(bounding_boxes, -1)

        cx = (x1 + x2) / 2
        cy = (y1 + y2) / 2
        width = x2 - x1
        height = y2 - y1

        return cx, cy, width, height

    def encode(self, bboxes: torch.Tensor, gt_bboxes: torch.Tensor) -> torch.Tensor:
        """Get box regression transformation deltas that can be used to
        transform the ``bboxes`` into the ``gt_bboxes``.

        Args:
            bboxes (torch.Tensor): Source boxes, e.g., object proposals.
            gt_bboxes (torch.Tensor): Target of the transformation, e.g., ground-truth boxes.

        Returns:
            torch.Tensor: Box transformation deltas
        """

        # Convert anchors to the center coordinate representation.
        xcenter_a, ycenter_a, wa, ha = self._get_center_coordinates_and_sizes(bboxes)
        xcenter, ycenter, w, h = self._get_center_coordinates_and_sizes(gt_bboxes)

        # Avoid NaN in division and log below.
        ha = ha + EPSILON
        wa = wa + EPSILON
        h = h + EPSILON
        w = w + EPSILON

        tx = (xcenter - xcenter_a) / wa
        ty = (ycenter - ycenter_a) / ha
        tw = torch.log(w / wa)
        th = torch.log(h / ha)
        # Scales location targets as used in paper for joint training.
        if self._scale_factors:
            tx = tx * self._scale_factors[0]
            ty = ty * self._scale_factors[1]
            tw = tw * self._scale_factors[2]
            th = th * self._scale_factors[3]
        return torch.stack([tx, ty, tw, th], dim=-1)

    def decode(
            self,
            bboxes: torch.Tensor,
            pred_bboxes: torch.Tensor,
            max_shape=None,
    ):
        """Apply transformation `pred_bboxes` to `boxes`.

        Args:
            bboxes (torch.Tensor): Basic boxes.
            pred_bboxes (torch.Tensor): Encoded boxes with shape
            max_shape (tuple[int], optional): Maximum shape of boxes.
                Defaults to None.

        Returns:
            torch.Tensor: Decoded boxes.
        """

        assert pred_bboxes.size(0) == bboxes.size(0)

        xcenter_a, ycenter_a, wa, ha = self._get_center_coordinates_and_sizes(bboxes)

        tx, ty, tw, th = torch.unbind(pred_bboxes, -1)

        if self._scale_factors:
            tx = tx / self._scale_factors[0]
            ty = ty / self._scale_factors[1]
            tw = tw / self._scale_factors[2]
            th = th / self._scale_factors[3]

        w = torch.exp(tw) * wa
        h = torch.exp(th) * ha
        xcenter = tx * wa + xcenter_a
        ycenter = ty * ha + ycenter_a

        decoded_bboxes = torch.stack(
            [
                xcenter - w / 2.,
                ycenter - h / 2.,
                xcenter + w / 2.,
                ycenter + h / 2.,
            ],
            dim=-1,
        )

        return decoded_bboxes
