from typing import List
from typing import Optional
from typing import Tuple

import numpy as np
import torch

if __name__ != '__main__':
    from .builder import ANCHOR_GENERATORS
else:
    from mmdet.core.anchor.builder import ANCHOR_GENERATORS


@ANCHOR_GENERATORS.register_module()
class ODApiSSDAnchorGenerator:
    """Anchor generator for SSD but using the OD-API style.

    This class reproduces ``default box`` construction proposed by Liu et al in the SSD paper.
    See Section 2.2 for details. Grid sizes are assumed to be passed in
    at generation time from finest resolution to coarsest resolution --- this is
    used to (linearly) interpolate scales of anchor boxes corresponding to the
    intermediate grid sizes.

    Args:
        input_size: integer/float size of the input image of the feature extractor.
        num_layers: integer number of grid layers to create anchors for (actual
            grid sizes passed in at generation time)
        min_scale: scale of anchors corresponding to finest resolution (float)
        max_scale: scale of anchors corresponding to coarsest resolution (float)
        scales: As list of anchor scales to use. When not None and not empty,
            min_scale and max_scale are not used.
        aspect_ratios: list or tuple of (float) aspect ratios to place on each
            grid point.
        interpolated_scale_aspect_ratio: An additional anchor is added with this
            aspect ratio and a scale interpolated between the scale for a layer
            and the scale for the next layer (1.0 for the last layer).
            This anchor is not included if this value is 0.
        reduce_boxes_in_lowest_layer: a boolean to indicate whether the fixed 3
            boxes per location is used in the lowest layer.
        base_anchor_height: The base anchor size in height dimension.
        base_anchor_width: The base anchor size in width dimension.
        height_stride: Anchor stride in height dimension in pixels for each layer. The
            length of this field is expected to be equal to the value of num_layers.
        width_stride: Anchor stride in width dimension in pixels for each layer. The
            length of this field is expected to be equal to the value of num_layers.
        height_offset: Anchor height offset in pixels for each layer.
            The length of this field is expected to be equal to the value of num_layers.
        width_offset: Anchor width offset in pixels for each layer.
            The length of this field is expected to be equal to the value of num_layers.
    """

    def __init__(
            self,
            *,
            input_size: float,
            num_layers: int,
            **anchors_cfg_params,
    ):
        parsed_parameters = parse_od_api_ssd_anchors_cfg(
            num_layers=num_layers,
            **anchors_cfg_params
        )

        box_specs_list, base_anchor_size, anchor_strides, anchor_offsets = create_ssd_anchors_specs(
            **parsed_parameters
        )

        # Assign object properties
        self._input_size = input_size  # In OD-API class this parameter is passed during the graph building.
        self._num_layers = num_layers

        # box_specs_list:
        #   list of list of (scale, aspect ratio) pairs with the
        #   outside list having the same number of entries as feature_map_shape_list
        #   (which is passed in at generation time).
        #   [
        #       [(layer1_scale1, layer1_aspect1), (layer1_scale2, layer1_aspect2), ...],
        #       [(layer2_scale1, layer2_aspect1), ...],
        #       ...
        #   ]
        self._box_specs_list: List[List[Tuple[float, float]]] = box_specs_list

        # base_anchor_size
        #   [base_anchor_height, base_anchor_width]
        self._base_anchor_size = torch.tensor(base_anchor_size, dtype=torch.float32)

        # anchor_strides:
        #   list of pairs of strides in pixels (in y and x directions
        #   respectively). For example, setting anchor_strides=[(25, 25), (50, 50)]
        #   means that we want the anchors corresponding to the first layer to be
        #   strided by 25 pixels and those in the second layer to be strided by 50 pixels in both y and x directions.
        #
        #   If anchor_strides=None, they are set to be the reciprocal of the corresponding feature map shapes.
        self._anchor_strides: List[Tuple[float, float]] = anchor_strides

        # anchor_offsets:
        #   list of pairs of offsets in pixels (in y and x directions
        #   respectively). The offset specifies where we want the center of the
        #   (0, 0)-th anchor to lie for each layer. For example, setting
        #   anchor_offsets=[(10, 10), (20, 20)]) means that we want the
        #   (0, 0)-th anchor of the first layer to lie at (10, 10) in pixel space
        #   and likewise that we want the (0, 0)-th anchor of the second layer to lie at (25, 25) in pixel space.
        #
        #   If anchor_offsets=None, then they are set to be half of the corresponding anchor stride.
        self._anchor_offsets: List[Tuple[float, float]] = anchor_offsets

        # The following code reproduce the code of the
        # `MultipleGridAnchorGenerator` class from the TF Object Detection API.

        # Split scales and aspect ratios into separate
        # lists of lists (for each feature level).
        self._scales: List[torch.Tensor] = []  # list of tensors defining scales for each level
        self._aspect_ratios: List[torch.Tensor] = []  # list of tensors defining the aspect ratio values for each level

        for box_spec in self._box_specs_list:
            scales, aspect_ratios = zip(*box_spec)
            self._scales.append(
                torch.tensor(scales, dtype=torch.float32)
            )
            self._aspect_ratios.append(
                torch.tensor(aspect_ratios, dtype=torch.float32)
            )

        self._base_anchors = self.gen_base_anchors()

    def _raise_special_attribute_error(self, attribute_name):
        raise AttributeError(f'Unable to access "{attribute_name}" attribute for "{self.__class__.__name__}" class.')

    def _check_feature_map_sizes(self, feature_map_sizes: List[Tuple]) -> None:
        if len(feature_map_sizes) != self._num_layers:
            raise ValueError(
                f'Incorrect number of feature maps sizes. '
                f'Expected {self._num_layers}, got {len(feature_map_sizes)}'
            )

    @property
    def num_base_anchors(self) -> List[int]:
        """list[int]: total number of base anchors in a feature grid"""
        return [base_anchors.size(0) for base_anchors in self._base_anchors]

    @property
    def num_levels(self) -> int:
        return self._num_layers

    def gen_base_anchors(self) -> List[torch.Tensor]:
        """Generate base anchors.

        Returns:
            list(torch.Tensor): Base anchors of a feature grid in multiple
                feature levels.
        """
        multi_level_base_anchors = [
            self.gen_single_level_base_anchors(
                scales=self._scales[i],
                ratios=self._aspect_ratios[i]
            )
            for i in range(self._num_layers)
        ]

        return multi_level_base_anchors

    def gen_single_level_base_anchors(self, scales, ratios) -> torch.Tensor:
        ratios_sqrt = torch.sqrt(ratios)
        heights = scales / ratios_sqrt * self._base_anchor_size[0]
        widths = scales * ratios_sqrt * self._base_anchor_size[1]

        # In TF OD-API implementation the offset is applied on the anchors-tiling stage.
        # The offset values in general case can be calculated only during the forward pass.
        # Therefore, the centers of anchor boxes are initially placed to
        # the left upper corners of grid cells.
        base_anchors = torch.stack(
            [
                - 0.5 * widths,
                - 0.5 * heights,
                0.5 * widths,
                0.5 * heights,
            ],
            dim=-1,
        )

        return base_anchors

    def _produce_strides_and_offsets(
            self,
            featmap_sizes: List[Tuple[int, int]],
    ) -> Tuple[List[Tuple[float, float]], List[Tuple[float, float]]]:
        """Produces strides and offsets data, based on the feature maps sizes.

        Anchor strides and offsets are normalized on the grid size / image size.

        Values are stored using (y, x) format.
        """

        img_size = self._input_size

        # Recalculate anchor strides
        if not self._anchor_strides:
            anchor_strides = [
                (1.0 / grid_h, 1.0 / grid_w)
                for grid_h, grid_w in featmap_sizes
            ]
        else:
            anchor_strides = [
                (stride_y / img_size, stride_x / img_size)
                for stride_y, stride_x in self._anchor_strides
            ]

        if not self._anchor_offsets:
            anchor_offsets = [
                (0.5 * stride_y, 0.5 * stride_x)
                for stride_y, stride_x in anchor_strides
            ]
        else:
            anchor_offsets = [
                (offset_y / img_size, offset_x / img_size)
                for offset_y, offset_x in self._anchor_offsets
            ]

        return anchor_strides, anchor_offsets

    def grid_anchors(self, featmap_sizes: List[Tuple[int, int]], device: str = 'cuda') -> List[torch.Tensor]:
        """Generate grid anchors in multiple feature levels.

        Args:
            featmap_sizes (list[tuple]): List of feature map sizes in
                multiple feature levels.
            device (str): Device where the anchors will be put on.

        Return:
            list[torch.Tensor]: Anchors in multiple feature levels.
                The sizes of each tensor should be [N, 4], where
                N = width * height * num_base_anchors, width and height
                are the sizes of the corresponding feature lavel,
                num_base_anchors is the number of anchors for that level.
        """
        self._check_feature_map_sizes(featmap_sizes)

        # Strides and offsets are in (y, x) format.
        anchor_strides, anchor_offsets = self._produce_strides_and_offsets(featmap_sizes)

        multi_level_anchors = [
            self.single_level_grid_anchors(
                self._base_anchors[i].to(device),
                featmap_sizes[i],
                anchor_strides[i],
                anchor_offsets[i],
                device=device,
            ) * self._input_size
            for i in range(self._num_layers)
        ]

        return multi_level_anchors

    def single_level_grid_anchors(
            self,
            base_anchors,
            featmap_size,
            stride,
            offset,
            device: str = 'cuda',
    ) -> torch.Tensor:
        """Generate grid anchors of a single level.

        Note:
            This function is usually called by method ``self.grid_anchors``.

        Args:
            base_anchors (torch.Tensor): The base anchors of a feature grid in XYXY format..
            featmap_size (tuple[int]): Size of the feature maps.
            stride (tuple[float, float]): Stride of the feature map (YX format).
            offset (tuple[float, float]): Offset of the feature map (YX format).
            device (str, optional): Device the tensor will be put on.
                Defaults to 'cuda'.

        Returns:
            torch.Tensor: Anchors in the overall feature maps.
        """
        feat_h, feat_w = featmap_size
        stride_y, stride_x = stride
        offset_y, offset_x = offset

        shift_x = torch.arange(0, feat_w, device=device, dtype=torch.float32) * stride_x + offset_x
        shift_y = torch.arange(0, feat_h, device=device, dtype=torch.float32) * stride_y + offset_y
        shift_xx, shift_yy = self._meshgrid(shift_x, shift_y)
        # shift_xx and shift_yy has shape [feat_h * feat_x] (K shifts)
        # The 2D representation of these tensors has shape [feat_h, feat_x]

        # The coordinates are ordered using (x, y, x, y) format
        shifts = torch.stack([shift_xx, shift_yy, shift_xx, shift_yy], dim=-1)  # [K, 4]
        shifts = shifts.type_as(base_anchors)
        # first feat_w elements correspond to the first row of shifts
        # add A anchors (1, A, 4) to K shifts (K, 1, 4) to get
        # shifted anchors (K, A, 4), reshape to (K * A, 4)
        # !!! This implementation matches the anchors generators implementation in TF OD-API.

        all_anchors = base_anchors[None, :, :] + shifts[:, None, :]  # [K, A, 4]
        all_anchors = all_anchors.view(-1, 4)  # [K*A, 4]
        # first A rows correspond to A anchors of (0, 0) in feature map,
        # then (0, 1), (0, 2), ...

        return all_anchors

    def valid_flags(
            self,
            featmap_sizes: List[Tuple[int, int]],
            pad_shape: Tuple[int, int],
            device: str = 'cuda',
    ) -> List[torch.Tensor]:
        """Generate valid flags of anchors in multiple feature levels.

        Args:
            featmap_sizes (list(tuple)): List of feature map sizes in
                multiple feature levels.
            pad_shape (tuple): The padded shape of the image.
            device (str): Device where the anchors will be put on.

        Return:
            list(torch.Tensor): Valid flags of anchors in multiple levels.
        """
        h, w = pad_shape[:2]
        if not (h == w == self._input_size):
            raise NotImplementedError('Image padding is not supported for the TF OD-API style anchors.')

        self._check_feature_map_sizes(featmap_sizes)

        anchor_strides, _ = self._produce_strides_and_offsets(featmap_sizes)
        levels_base_anchors_num = self.num_base_anchors

        multi_level_flags = []
        for i in range(self._num_layers):
            stride_y, stride_x = anchor_strides[i]
            feat_h, feat_w = featmap_sizes[i]

            valid_feat_h = min(int(1. / stride_y), feat_h)
            valid_feat_w = min(int(1. / stride_x), feat_w)

            flags = self.single_level_valid_flags(
                (feat_h, feat_w),
                (valid_feat_h, valid_feat_w),
                levels_base_anchors_num[i],
                device=device,
            )
            multi_level_flags.append(flags)
        return multi_level_flags

    def single_level_valid_flags(
            self,
            featmap_size,
            valid_size,
            num_base_anchors,
            device='cuda',
    ):
        """Generate the valid flags of anchor in a single feature map.

        Args:
            featmap_size (tuple[int]): The size of feature maps.
            valid_size (tuple[int]): The valid size of the feature maps.
            num_base_anchors (int): The number of base anchors.
            device (str, optional): Device where the flags will be put on.
                Defaults to 'cuda'.

        Returns:
            torch.Tensor: The valid flags of each anchor in a single level
                feature map.
        """
        feat_h, feat_w = featmap_size
        valid_h, valid_w = valid_size

        assert valid_h <= feat_h and valid_w <= feat_w

        valid_x = torch.zeros(feat_w, dtype=torch.bool, device=device)
        valid_y = torch.zeros(feat_h, dtype=torch.bool, device=device)
        valid_x[:valid_w] = 1
        valid_y[:valid_h] = 1
        valid_xx, valid_yy = self._meshgrid(valid_x, valid_y)
        valid = valid_xx & valid_yy
        valid = valid[:, None].expand(valid.size(0), num_base_anchors).contiguous().view(-1)
        return valid

    @staticmethod
    def _meshgrid(x, y):
        """Generate mesh grid of x and y.

        Args:
            x (torch.Tensor): Grids of x dimension.
            y (torch.Tensor): Grids of y dimension.

        Returns:
            tuple[torch.Tensor]: The mesh grids of x and y.
        """
        xx = x.repeat(len(y))
        yy = y.view(-1, 1).repeat(1, len(x)).view(-1)
        return xx, yy

    def __repr__(self):
        """str: a string that describes the module"""
        indent_str = '    '
        repr_str = self.__class__.__name__ + '(\n'
        repr_str += f'{indent_str}_box_specs_list={self._box_specs_list},\n'
        repr_str += f'{indent_str}_input_size={self._input_size},\n'
        repr_str += f'{indent_str}num_levels={self.num_levels},\n'
        repr_str += f'{indent_str}_base_anchor_size={self._base_anchor_size},\n'
        repr_str += f'{indent_str}_anchor_strides={self._anchor_strides},\n'
        repr_str += f'{indent_str}_anchor_offsets={self._anchor_offsets},\n'
        return repr_str


def create_ssd_anchors_specs(
        num_layers: int,
        min_scale: float,
        max_scale: float,
        scales: Optional[List[float]],
        aspect_ratios: List[float],
        base_anchor_size: Optional[List[Tuple[float, float]]],
        anchor_strides: Optional[List[Tuple[int, int]]],
        anchor_offsets: Optional[List[Tuple[int, int]]],
        reduce_boxes_in_lowest_layer: bool,
        interpolated_scale_aspect_ratio: float,
):
    """Create SSD anchors specs.

    Args:
      num_layers: integer number of grid layers to create anchors for (actual
        grid sizes passed in at generation time)
      min_scale: scale of anchors corresponding to finest resolution (float)
      max_scale: scale of anchors corresponding to coarsest resolution (float)
      scales: As list of anchor scales to use. When not None and not empty,
        min_scale and max_scale are not used.
      aspect_ratios: list or tuple of (float) aspect ratios to place on each
        grid point.
      interpolated_scale_aspect_ratio: An additional anchor is added with this
        aspect ratio and a scale interpolated between the scale for a layer
        and the scale for the next layer (1.0 for the last layer).
        This anchor is not included if this value is 0.
      base_anchor_size: base anchor size as [height, width].
        The height and width values are normalized to the minimum dimension of the
        input height and width, so that when the base anchor height equals the
        base anchor width, the resulting anchor is square even if the input image
        is not square.
      anchor_strides: list of pairs of strides in pixels (in y and x directions
        respectively). For example, setting anchor_strides=[(25, 25), (50, 50)]
        means that we want the anchors corresponding to the first layer to be
        strided by 25 pixels and those in the second layer to be strided by 50
        pixels in both y and x directions. If anchor_strides=None, they are set to
        be the reciprocal of the corresponding feature map shapes.
      anchor_offsets: list of pairs of offsets in pixels (in y and x directions
        respectively). The offset specifies where we want the center of the
        (0, 0)-th anchor to lie for each layer. For example, setting
        anchor_offsets=[(10, 10), (20, 20)]) means that we want the
        (0, 0)-th anchor of the first layer to lie at (10, 10) in pixel space
        and likewise that we want the (0, 0)-th anchor of the second layer to lie
        at (25, 25) in pixel space. If anchor_offsets=None, then they are set to
        be half of the corresponding anchor stride.
      reduce_boxes_in_lowest_layer: a boolean to indicate whether the fixed 3
        boxes per location is used in the lowest layer.
    """
    if not isinstance(num_layers, int) or num_layers < 1:
        raise ValueError(
            f'Number of layers must be specified using an integer '
            f'number and greater than zero. Got {num_layers}'
        )

    if base_anchor_size is None:
        base_anchor_size = [1.0, 1.0]

    # Process anchor boxes scales
    if scales is None or not scales:
        scales = list(np.linspace(min_scale, max_scale, num_layers)) + [1.0]
    else:
        if len(scales) != num_layers:
            raise ValueError(
                f'Number of scales ({len(scales)}) is not equal to '
                f'the specified number of layers ({num_layers})'
            )
        scales = list(scales)

    # For scales add 1.0 to the end, which will only be used in scale_next below and used
    # for computing an interpolated scale for the largest scale in the list.
    scales = scales + [1.0]

    box_specs_list = []

    for layer_index, scale, scale_next in zip(range(num_layers), scales[:-1], scales[1:]):
        layer_box_specs = []
        if layer_index == 0 and reduce_boxes_in_lowest_layer:
            layer_box_specs = [(0.1, 1.0), (scale, 2.0), (scale, 0.5)]
        else:
            for aspect_ratio in aspect_ratios:
                layer_box_specs.append((scale, aspect_ratio))
            # Add one more anchor, with a scale between the current scale, and the
            # scale for the next layer, with a specified aspect ratio (1.0 by default).
            if interpolated_scale_aspect_ratio > 0.0:
                layer_box_specs.append((np.sqrt(scale * scale_next), interpolated_scale_aspect_ratio))
        box_specs_list.append(layer_box_specs)

    return box_specs_list, base_anchor_size, anchor_strides, anchor_offsets


def parse_od_api_ssd_anchors_cfg(**cfg):
    num_layers = cfg['num_layers']

    # Process anchor strides
    width_stride = cfg.get('width_stride', None)
    height_stride = cfg.get('height_stride', None)
    anchor_strides = None

    if width_stride and height_stride:
        if len(width_stride) != num_layers or len(height_stride) != num_layers:
            raise ValueError(
                'Length of width/height strides lists must be '
                'equal to num_layers (number of probe features).'
            )
        anchor_strides = list(zip(height_stride, width_stride))

    elif width_stride or height_stride:
        raise ValueError(
            'If anchors strides are defined, both width and height strides must be defined'
        )

    # Process anchor offsets
    width_offset = cfg.get('width_offset', None)
    height_offset = cfg.get('height_offset', None)
    anchor_offsets = None

    if width_offset and height_offset:
        if len(width_offset) != num_layers or len(height_offset) != num_layers:
            raise ValueError(
                'Length of width/height offsets lists must be '
                'equal to num_layers (number of probe features).'
            )
        anchor_offsets = list(zip(height_offset, width_offset))

    elif width_offset or height_offset:
        raise ValueError(
            'If anchors offsets are defined, both width and height strides must be defined'
        )

    parsed_cfg = {
        'num_layers': num_layers,
        'min_scale': cfg['min_scale'],
        'max_scale': cfg['max_scale'],
        'scales': cfg.get('scales', []),
        'aspect_ratios': cfg.get('aspect_ratios', []),
        'interpolated_scale_aspect_ratio': float(cfg.get('interpolated_scale_aspect_ratio', 1.0)),
        'reduce_boxes_in_lowest_layer': bool(cfg.get('reduce_boxes_in_lowest_layer', True)),
        'base_anchor_size': [
            cfg.get('base_anchor_height', 1.0),
            cfg.get('base_anchor_width', 1.0),
        ],
        'anchor_strides': anchor_strides,
        'anchor_offsets': anchor_offsets,
    }

    return parsed_cfg


def print_anchors_specs():
    input_size = 200
    anchor_generator = ODApiSSDAnchorGenerator(
        input_size=input_size,
        num_layers=2,
        min_scale=0.5,
        max_scale=0.95,
        aspect_ratios=[1.0],
    )

    anchors = anchor_generator.grid_anchors([(7, 7), (4, 4)], device='cpu')
    all_anchors = torch.cat(anchors)
    all_anchors_numpy = all_anchors.cpu().numpy()
    ws = all_anchors_numpy[:, 2] - all_anchors_numpy[:, 0]
    hs = all_anchors_numpy[:, 3] - all_anchors_numpy[:, 1]
    xc = (all_anchors_numpy[:, 2] + all_anchors_numpy[:, 0]) / 2
    yc = (all_anchors_numpy[:, 3] + all_anchors_numpy[:, 1]) / 2
    _tflite_format = np.stack([yc, xc, hs, ws], -1) / input_size
    print(anchor_generator)
    print('Finished')


if __name__ == '__main__':
    print_anchors_specs()
